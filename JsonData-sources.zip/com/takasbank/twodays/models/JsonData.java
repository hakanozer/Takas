
package com.takasbank.twodays.models;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class JsonData {

    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("start")
    @Expose
    private Integer start;
    @SerializedName("stop")
    @Expose
    private Integer stop;
    @SerializedName("version")
    @Expose
    private String version;
    @SerializedName("testCases")
    @Expose
    private List<TestCase> testCases = null;
    @SerializedName("labels")
    @Expose
    private List<Label_> labels = null;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getStart() {
        return start;
    }

    public void setStart(Integer start) {
        this.start = start;
    }

    public Integer getStop() {
        return stop;
    }

    public void setStop(Integer stop) {
        this.stop = stop;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public List<TestCase> getTestCases() {
        return testCases;
    }

    public void setTestCases(List<TestCase> testCases) {
        this.testCases = testCases;
    }

    public List<Label_> getLabels() {
        return labels;
    }

    public void setLabels(List<Label_> labels) {
        this.labels = labels;
    }

}
