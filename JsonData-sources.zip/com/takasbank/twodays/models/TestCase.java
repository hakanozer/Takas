
package com.takasbank.twodays.models;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class TestCase {

    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("start")
    @Expose
    private Integer start;
    @SerializedName("stop")
    @Expose
    private Integer stop;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("labels")
    @Expose
    private List<Label> labels = null;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getStart() {
        return start;
    }

    public void setStart(Integer start) {
        this.start = start;
    }

    public Integer getStop() {
        return stop;
    }

    public void setStop(Integer stop) {
        this.stop = stop;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<Label> getLabels() {
        return labels;
    }

    public void setLabels(List<Label> labels) {
        this.labels = labels;
    }

}
