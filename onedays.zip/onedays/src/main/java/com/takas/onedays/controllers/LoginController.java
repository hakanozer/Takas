package com.takas.onedays.controllers;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.takas.onedays.models.User;
import com.takas.onedays.util.DB;

@Controller
public class LoginController {
	
	DB db = new DB();
	String sessionID = "";
	
	@GetMapping("/")
	public String login( HttpServletRequest req ) {
		sessionID = req.getSession().getId();
		System.out.println("sessionID " + sessionID);
		return "login";
	}
	
	
	// user login
	@PostMapping("/login")
	public String loginUser( User us, Model model, HttpServletRequest req,
			@RequestParam(defaultValue = "") String remember_me,
			HttpServletResponse res
			) {
		try {
			String query = "select * from user where mail = ? and pass = ?";
			PreparedStatement pre = db.preBaglan(query);
			pre.setString(1, us.getMail());
			pre.setString(2, us.getPass());
			ResultSet rs = pre.executeQuery();
			if(rs.next()) {
				// session create
				//us.setRole(rs.getString("role"));
				req.getSession().setAttribute("user", us);
				model.addAttribute("statu", "true");
				
				// Cookie Control
				if (!remember_me.equals("")) {
					Cookie cookie = new Cookie("user", us.getMail() );
					cookie.setMaxAge(60 * 60);
					res.addCookie(cookie);
				}
				
				return "redirect:/dashboard?statux=true";
			}
		} catch (Exception e) {
			System.err.println("Login error : " + e);
		}
		return "login";
	}
	
	
	

}
