package com.takas.onedays.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HomeController {
	
	
	@RequestMapping( name = "/", method = RequestMethod.GET )
	public String home( Model model ) {
		model.addAttribute("name", "Ali Bilmem");
		model.addAttribute("data", dataResult());
		return "home";
	}
	
	
	public List<String> dataResult() {
		List<String> ls = new ArrayList<>();
		ls.add("Ali");
		ls.add("Erkan");
		ls.add("Serkan");
		return ls;
	}
	

}
