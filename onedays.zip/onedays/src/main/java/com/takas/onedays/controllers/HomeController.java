package com.takas.onedays.controllers;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.takas.onedays.models.User;
import com.takas.onedays.util.DB;
import com.takas.onedays.util.Util;

@Controller
// @RequestMapping("/admin")
public class HomeController {
	
	DB db = new DB();
	
	
	@RequestMapping( name = "/dashboard", method = RequestMethod.GET )
	public String home( Model model, HttpServletRequest req ) {
		model.addAttribute("name", "Ali Bilmem");
		model.addAttribute("data", dataResult());
		model.addAttribute("alluser", allUser());
		return Util.control("home", req);
	}
	
	
	
	public List<String> dataResult() {
		List<String> ls = new ArrayList<>();
		ls.add("Ali");
		ls.add("Erkan");
		ls.add("Serkan");
		return ls;
	}
	
	
	// User insert
	@PostMapping("/userInsert")
	public String userInsert( 
			User us
			//@RequestParam(name = "mail") String mail,
			//@RequestParam String pass
			) {
		//System.out.println("mail : " + mail + " pass : " + pass);
		System.out.println("mail : " + us.getMail() + " pass : " + us.getPass());
		dbInsert(us);
		return "redirect:/dashboard";
	}
	
	
	public int dbInsert(User us) {
		if (!us.getMail().equals("")  && !us.getPass().equals("") ) {
			try {
				String query = "insert into user values ( null, ?, ?, now() )";
				PreparedStatement pre = db.preBaglan(query);
				pre.setString(1, us.getMail());
				pre.setString(2, us.getPass());
				return pre.executeUpdate();
			} catch (Exception e) {
				System.err.println("insert error : " + e);
			}
		}
		
		return 0;
	}
	
	
	public List<User> allUser() {
		List<User> ls = new ArrayList<>();
		try {
			String query = "select * from user";
			PreparedStatement pre = db.preBaglan(query);
			ResultSet rs = pre.executeQuery();
			
			while(rs.next()) {
				User us = new User();
				us.setUid(rs.getString("uid"));
				us.setMail(rs.getString("mail"));
				us.setPass(rs.getString("pass"));
				us.setuDate(rs.getString("uDate"));
				ls.add(us);
			}
			
		} catch (Exception e) {
			System.err.println("select error : " + e);
		}
		return ls;
	}
	
	
	@GetMapping("/userDelete/{uid}")
	public String userDelete( @PathVariable String uid ) {
		try {
			String query = "delete from user where uid = ?";
			PreparedStatement pre = db.preBaglan(query);
			pre.setInt(1, Integer.valueOf(uid));
			pre.executeUpdate();
		} catch (Exception e) {
			System.err.println("delete error : " + e);
		}
		return "redirect:/dashboard"; 
	}
	
	

}
