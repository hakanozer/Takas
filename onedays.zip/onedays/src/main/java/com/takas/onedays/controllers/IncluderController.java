package com.takas.onedays.controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.takas.onedays.models.User;

@Controller
public class IncluderController {
	
	
	// menu
	@GetMapping("/menu")
	public String menu( Model model, HttpServletRequest req ) {
		User us = (User) req.getSession().getAttribute("user");
		model.addAttribute("user", us);
		String backColor = "#f8f9fa !important";
		if(us.getMail().equals("ali@mail.com")) {
			backColor = "#ff0000 !important";
		}
		model.addAttribute("backColor", backColor);
		return "inc/menu";
	}

}
