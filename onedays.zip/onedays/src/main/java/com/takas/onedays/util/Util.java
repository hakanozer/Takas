package com.takas.onedays.util;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import com.takas.onedays.models.User;

public class Util {
	
	
	public static String control( String page, HttpServletRequest req ) {
		
		// Cookie control
		if( req.getCookies() != null ) {
			Cookie[] arr = req.getCookies();
			for (Cookie cookie : arr) {
				if(cookie.getName().equals("user")) {
					String mail = cookie.getValue();
					User us = new User();
					us.setMail(mail);
					req.getSession().setAttribute("user", us);
					break;
				}
			}
		}
		
		
		// req.getSession().getId();
		boolean statu = req.getSession().getAttribute("user") == null;
		// before session id
		// after session id
		String sessionid = req.getSession().getId();
		
		if(statu) {
			return "redirect:/";
		}
		User us = (User) req.getSession().getAttribute("user");
		return page;
		
	}

}
