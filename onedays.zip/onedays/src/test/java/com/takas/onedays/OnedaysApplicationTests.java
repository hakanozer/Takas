package com.takas.onedays;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnedaysApplicationTests {

	@Test
	void contextLoads() {
	}

}
