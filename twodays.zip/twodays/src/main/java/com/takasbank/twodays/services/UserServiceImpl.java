package com.takasbank.twodays.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.takasbank.twodays.models.User;
import com.takasbank.twodays.restrepositories.UserRepository;

@Service
public class UserServiceImpl implements UserInterface {

	@Autowired UserRepository userRepository;
	
	@Override
	public ResponseEntity<User> newUser(User us) {
		User u = userRepository.save(us);
		return new ResponseEntity<User>(u, HttpStatus.CREATED);
	}

	
	

}
