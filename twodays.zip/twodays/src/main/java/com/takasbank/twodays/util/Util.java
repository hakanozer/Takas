package com.takasbank.twodays.util;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;

public class Util {
	
	
	public static void userData() {
		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		UserDetails userDetails = (UserDetails) authentication.getPrincipal();

		// getUsername() - Returns the username used to authenticate the user.
		System.out.println("User name: " + userDetails.getUsername());

		// getAuthorities() - Returns the authorities granted to the user.
		System.out.println("User has authorities: " + userDetails.getAuthorities());
		
	}

}
