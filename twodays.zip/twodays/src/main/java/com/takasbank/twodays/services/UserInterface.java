package com.takasbank.twodays.services;

import org.springframework.http.ResponseEntity;

import com.takasbank.twodays.models.User;

public interface UserInterface {

	public ResponseEntity<User> newUser( User us );
	
}
