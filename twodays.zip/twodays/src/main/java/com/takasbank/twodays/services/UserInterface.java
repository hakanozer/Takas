package com.takasbank.twodays.services;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.http.ResponseEntity;

import com.takasbank.twodays.models.User;

public interface UserInterface {

	public ResponseEntity<User> newUser( User us );
	public List<User> allJpaUser();
	
}
