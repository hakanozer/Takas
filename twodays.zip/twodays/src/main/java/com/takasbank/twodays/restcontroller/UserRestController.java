package com.takasbank.twodays.restcontroller;

import java.lang.reflect.Type;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.takasbank.twodays.models.Todo;
import com.takasbank.twodays.models.User;
import com.takasbank.twodays.restrepositories.UserRepository;
import com.takasbank.twodays.services.UserInterface;
import com.takasbank.twodays.services.UserServiceImpl;

@RestController
public class UserRestController {
	
	@Autowired UserInterface userInterface;
	@Autowired DriverManagerDataSource db;

	@GetMapping("/allUser")
	public Map<String, Object> allUser() {
		Map<String, Object> hm = new LinkedHashMap<>();
		hm.put("name", "Ali");
		hm.put("age", 39);
		hm.put("statu", true);
		hm.put("users", allUserResult());
		hm.put("allJpaUser", allJpaUser());
		return hm;
	}
	
	
	
	@GetMapping("/userInsert")
	public ResponseEntity<User> userInsert( User us ) {
		us.setUdate(new Date());
		//return userRepository.saveAndFlush(us);
		return userInterface.newUser(us);
	}
	
	
	public List<User> allUserResult() {
		List<User> ls = new ArrayList<>();
		
		try {
			String query = "select * from user";
			PreparedStatement pre = db.getConnection().prepareStatement(query);
			ResultSet rs = pre.executeQuery();
			while(rs.next()) {
				User us = new User();
				us.setMail(rs.getString("mail"));
				us.setPass(rs.getString("pass"));
				us.setUdate(rs.getDate("udate"));
				us.setUid(rs.getInt("uid"));
				ls.add(us);
			}
		} catch (Exception e) {
			System.err.println("Select Error : " + e);
		}
		
		return ls;
	}
	
	
	
	// jpa data result
	public List<User> allJpaUser() {
		return userInterface.allJpaUser();
	}
	
	
	
	// RestRead
	@GetMapping("/restRead")
	public Map<String, Object> restRead() {
		String url = "https://jsonplaceholder.typicode.com/todos";
		RestTemplate rest = new RestTemplate();
		String data = rest.getForObject(url, String.class);
		//System.out.println("Data : " + data);
		
		Type collectionType = new TypeToken<List<Todo>>(){}.getType();
		Gson gson = new Gson();
		List<Todo> ls = gson.fromJson(data, collectionType);
		
		for (Todo todo : ls) {
			System.out.println("item : " + todo.getTitle());
		}
		
		Map<String, Object> hm = new LinkedHashMap<>();
		hm.put("statu", true);
		hm.put("list", ls);
		
		return hm;
	}
	
	
	
	
	
}
