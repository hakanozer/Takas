package com.takasbank.twodays.restcontroller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.takasbank.twodays.models.User;
import com.takasbank.twodays.restrepositories.UserRepository;
import com.takasbank.twodays.services.UserInterface;
import com.takasbank.twodays.services.UserServiceImpl;

@RestController
public class UserRestController {
	
	@Autowired UserInterface userInterface;

	@GetMapping("/allUser")
	public Map<String, Object> allUser() {
		Map<String, Object> hm = new LinkedHashMap<>();
		hm.put("name", "Ali");
		hm.put("age", 39);
		hm.put("statu", true);
		hm.put("users", allUserResult());
		return hm;
	}
	
	
	
	@GetMapping("/userInsert")
	public ResponseEntity<User> userInsert( User us ) {
		us.setUdate(new Date());
		//return userRepository.saveAndFlush(us);
		return userInterface.newUser(us);
	}
	
	
	public List<User> allUserResult() {
		List<User> ls = new ArrayList<>();
		for (int i = 0; i < 10; i++) {
			User us = new User();
			us.setMail("mail " + i);
			us.setPass("12"+i);
			us.setUdate(new Date());
			us.setUid(i);
			ls.add(us);
		}
		return ls;
	}
	
	
	
}
