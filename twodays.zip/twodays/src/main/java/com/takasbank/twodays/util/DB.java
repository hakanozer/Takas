package com.takasbank.twodays.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
@PropertySource("classpath:application.properties")
public class DB {
	
	@Value("${spring.datasource.url}")
	private String url;
	
	@Value("${spring.datasource.username}")
	private String userName;
	
	
	@Value("${spring.datasource.password}")
	private String pass;
	
	
	@Bean(name = "db")
	public DriverManagerDataSource sources() {
		DriverManagerDataSource db = new DriverManagerDataSource();
		db.setUrl(url);
		db.setUsername(userName);
		db.setPassword(pass);
		return db;
	}
	
	

}
